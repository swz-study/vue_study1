<template>
    <div>
        <h3>SearchContainer</h3>
    </div>
</template>

<script>
    export default {
        name: "SearchContainer"
    }
</script>

<style lang="scss" scoped>

</style>