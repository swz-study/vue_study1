<template>
    <div>
    <h3>MemberContainer</h3>
</div>
</template>

<script>
    export default {
        name: "MemberContainer"
    }
</script>

<style lang="scss" scoped>

</style>